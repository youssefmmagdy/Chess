package Model;

public enum Color {
        WHITE, RED
}
